CLUB WALLET – DEMO INTEGRAT

Deschide index.html într-un browser real (Safari/Chrome), nu în previzualizatorul de fișiere al aplicației.

Include:
- categorii Soft Drinks / Long Drinks
- + / - cantități
- coș persistent
- sold tokeni
- top-up demo
- plasare comandă
- număr unic de comandă
- QR pentru comandă
- istoric comenzi
- simulare scanare/preparare
- roluri Client / Casier / Barman / Admin
- stoc și scădere automată a stocului în demo
- localStorage pentru păstrarea datelor pe dispozitiv

IMPORTANT:
Este un prototip funcțional local. Plățile reale, autentificarea, baza de date centrală, scanarea QR cu camera, Stripe și sincronizarea între telefoane necesită backend.
